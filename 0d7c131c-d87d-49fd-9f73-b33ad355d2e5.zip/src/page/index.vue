<template>
  <div class="main-container">
    <div class="rectangle"></div>
    <div class="flex-column-a">
      <div class="cancel"><div class="cancel-1"></div></div>
      <span class="repricer-wb-bot">REPRICER WB BOT</span>
      <div class="toolbar">
        <span class="lichnyy-kabinet">Личный кабинет</span>
      </div>
      <button class="my-configurations">
        <span class="moi-konfiguracii">Мои конфигурации</span>
      </button>
      <div class="frame">
        <button class="config-button">
          <div class="rectangle-2"></div>
          <span class="config-number">Конфигурация № 1</span>
          <div class="arrow-icon"></div>
        </button>
      </div>
      <button class="add-config-button">
        <div class="rectangle-3"></div>
        <span class="add-configuration">Добавить конфигурацию</span>
      </button>
      <div class="edit-section">
        <span class="edit-text">Редактировать</span>
      </div>
    </div>
    <div class="config-section">
      <div class="default-property">
        <div class="rectangle-4"></div>
        <span class="config-number-5">Конфигурация № 1</span>
        <div class="arrow-forward-ios"></div>
      </div>
      <div class="property-variant">
        <div class="flex-row-de">
          <div class="rectangle-6"></div>
          <span class="config-number-7">Конфигурация № 1</span>
          <div class="arrow-forward-ios-8"></div>
        </div>
        <div class="flex-row">
          <div class="block-background"></div>
          <div class="non-editable-text">
            <span class="your-product">Ваш товар:</span
            ><span class="url-1">Url 1:</span><span class="url-2">Url 2:</span
            ><span class="url-3">Url 3:</span
            ><span class="min-price">Мин. цена:</span
            ><span class="discount">Скидка:</span>
            <div class="decrease">
              <span class="decrease-9">Снижать</span
              ><span class="exclamation">!</span>
            </div>
          </div>
          <span class="sku">sku</span><span class="www-url1">www.url1</span
          ><span class="www-url2">www.url2</span
          ><span class="www-url3">www.url3</span
          ><span class="min-price-a">min_price</span
          ><span class="sale">sale</span>
          <div class="edit"><span class="edit-b">Редактировать</span></div>
          <div class="delete"></div>
          <span class="delete-c">Удалить</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="javascript"></script>

<style src="./index.css"></style>
