<template>
    <div>
        <Page />
    </div>
</template>

<script setup>
import Page from './page/index.vue'
</script>
